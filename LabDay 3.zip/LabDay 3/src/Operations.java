
import java.util.Scanner;


public class Operations {

	public static void main(String[] args) {
		Operations op=new Operations();
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a String:");
		String str = sc.nextLine() ;

		System.out.println("\n 1. To add string\n 2.Replace with #\n 3. Remove Dulpicate Characters \n 4. Upper case");
		int i=sc.nextInt();
		if(i==1)
		{
			System.out.println("Added String"+ op.add(str));
		}
		else if(i==2)
		{
			System.out.println("Replace String"+op.replaceOdd(str));
		}
		else if(i==3)
		{
			System.out.println("Duplicate String"+op.duplicate(str));
		}
		else if(i==4)
		{
			System.out.println("Upper Case String"+op.upperCase(str));
		}
		else
		{
			System.out.println("wrong entry");

		}
	}

	public String add(String st)
	{
		String ss=st ;
		return ss+st ;	   
	}


	public String replaceOdd(String st)
	{
		String str1=" ";
		char stArray[] =st.toCharArray() ;

		for(int i=0;i<stArray.length ; i++)
		{
			if(i%2!=0)
			{
				str1="#";

			}
			else
			{
				str1=""+ st.charAt(i);
			}
		}
		return str1;
	}

	public String duplicate(String st)
	{
		String result="";
		for(int i=0;i<st.length();i++)
		{
			if(!result.contains(String.valueOf(st.charAt(i))))
			{
				result +=String.valueOf(st.charAt(i));

			}
		}
		return result;
	}

	public String upperCase(String st)
	{
		String result="";
		for(int i=0;i<st.length();i++)
		{
			if(i%2==0)
			{
				result +=Character.toUpperCase(st.charAt(i));
			}
			else
				result+= Character.toLowerCase(st.charAt(i));
		}
		return result;
	}

}


