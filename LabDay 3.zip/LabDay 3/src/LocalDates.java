import java.time.*;
import java.util.*;
public class LocalDates 
{

	public static void main(String[] args) 
	{
		LocalDate p1Date=LocalDate.of(2000, 1, 8);
		LocalDate p2Date=LocalDate.of(2010,2,10);
		Period diff=Period.between(p1Date, p2Date);
		System.out.printf("\n Difference is %d years, %d months, "
				+ "%d days old \n\n", 
				diff.getYears(),diff.getMonths(),diff.getDays());

	}

}
