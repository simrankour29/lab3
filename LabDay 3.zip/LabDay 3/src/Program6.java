import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

public class Program6 
{
	public static void main(String args[])
	{
		ZoneId zone1=ZoneId.of("America/New_York");
		ZoneId zone2=ZoneId.of("Europe/London");

		LocalDate dateNow1=LocalDate.now(zone1);
		LocalDate dateNow2=LocalDate.now(zone2);


		LocalTime timeNow1=LocalTime.now(zone1);
		LocalTime timeNow2=LocalTime.now(zone2);

		System.out.println("America/New_York"+dateNow1+""+timeNow1);
		System.out.println("Europe/London"+dateNow2+""+timeNow2);


	}

}
