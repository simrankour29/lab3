import java.util.Scanner;
class User
{
	public Boolean UName(String str)
	{
		boolean temp;
		String _job="_job";
		if(str.length()>=8)
		{
			System.out.println("UserName= "+str+_job+"\n");
			temp=true;
		}
		else
		{
			temp=false;
		}
		return temp;
	}

}
public class Username_job
{
	public static void main(String[] args) 
	{ 
		System.out.println("Enter username");
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		User obj=new User();
		System.out.println(obj.UName(input));
		sc.close();
	}
}

